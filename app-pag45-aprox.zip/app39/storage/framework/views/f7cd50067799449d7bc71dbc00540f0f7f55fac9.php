<?php $__env->startSection('titulo', 'Todos los usuarios'); ?>

<?php $__env->startSection('contenido'); ?>
    <br>
    <h3>Todos los usuarios</h3>
    
    <a class="btn btn-primary btn-sm float-right" href="<?php echo e(route('usuarios.create')); ?>">Crear nuevo usuario</a>

    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Tipo</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td>
                        
                        <?php echo e($usuario->roles->pluck('nombre')->implode(' - ')); ?>

					</td>
                    <td><?php echo e($usuario->address); ?></td>
                    <td><?php echo e($usuario->phone); ?></td>
                    <td>
                        <div class="btn-group" role="group">
                            <div class="col-md-6 custom">
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('usuarios.edit', $usuario->id)); ?>">Editar</a>    
                            </div>

                            <div class="col-md-6 custom">
                                <form method="POST" action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app36\resources\views/usuarios/index.blade.php ENDPATH**/ ?>