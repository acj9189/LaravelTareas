<?php $__env->startSection('titulo', 'Contacto'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Contacto</h1>

	<form method="post" action=<?php echo e(route('mensajes.store')); ?>>
		
		<?php echo $__env->make('mensajes.form', ['mensaje' => new App\Mensaje], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app36\resources\views/mensajes/crear.blade.php ENDPATH**/ ?>