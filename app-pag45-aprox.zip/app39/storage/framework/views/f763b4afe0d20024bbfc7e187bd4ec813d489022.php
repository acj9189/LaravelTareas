<?php $__env->startSection('titulo', 'Contacto'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Contacto</h1>

	<form method="post" action=<?php echo e(route('mensajes.store')); ?>>
		<?php echo csrf_field(); ?>

		<div class="form-group">
			<label for="nombre">Nombre</label>
			<input type="input" class="form-control" id="nombre" name="nombre" placeholder="Ingrese aquí su nombre">
		</div>

		<div class="form-group">
			<label for="correo">Correo</label>
			<input type="email" class="form-control" id="correo" name="correo" placeholder="Ingrese aquí su correo">
		</div>

		<div class="form-group">
			<label for="asunto">Asunto</label>
			<input type="input" class="form-control" id="asunto" name="asunto" placeholder="Motivo por el que se comunica con nosotros">
		</div>

		<div class="form-group">
			<label for="contenido">Contenido</label>
			<textarea class="form-control" id="contenido" name="contenido" rows="3"></textarea>
		</div>

		<button type="submit" class="btn btn-primary">Enviar</button>
	</form>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app29\resources\views/mensajes/crear.blade.php ENDPATH**/ ?>