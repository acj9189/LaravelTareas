<?php $__env->startSection('titulo', 'Todos los mensajes'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Todos los mensajes</h1>

    <table width="100%" border="1">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Asunto</th>
                <th>Contenido</th>
                <th>Acciones</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td>
                        <a href="<?php echo e(route('mensajes.show', $mensaje->id)); ?>">
                            <?php echo e($mensaje->nombre); ?>

                        </a>
                    </td>
                    <td><?php echo e($mensaje->email); ?></td>
                    <td><?php echo e($mensaje->asunto); ?></td>
                    <td><?php echo e($mensaje->contenido); ?></td>
                    <td>
                        <a href="<?php echo e(route('mensajes.edit', $mensaje->id)); ?>">Editar</a>
                        <form style="display:inline" method="POST" action="<?php echo e(route('mensajes.destroy', $mensaje->id)); ?>">
                            <?php echo csrf_field(); ?>
                            <?php echo method_field('DELETE'); ?>

                            <button type="submit">Eliminar</button>
                        </form>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app18b\resources\views/mensajes/index.blade.php ENDPATH**/ ?>