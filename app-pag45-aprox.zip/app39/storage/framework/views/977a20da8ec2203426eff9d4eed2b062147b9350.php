<nav>
    <li class="<?php echo e(seleccionado('inicio')); ?>"><a href="/">Inicio</a></li>
    <li class="<?php echo e(seleccionado('acercade')); ?>"><a href="acercade">Acerca de...</a></li>
    <li class="<?php echo e(seleccionado('catalogo')); ?>"><a href="catalogo">Catálogo</a></li>
    <li class="<?php echo e(seleccionado('contacto')); ?>"><a href="contacto">Contacto</a></li>
</nav><?php /**PATH D:\laragon\www\app16\resources\views/partials/nav.blade.php ENDPATH**/ ?>