<?php $__env->startSection('titulo', 'Mensaje'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Mensajes</h1>

    <p> Enviado por <?php echo e($mensaje->nombre); ?> - <?php echo e($mensaje->email); ?></p>
    <p> <?php echo e($mensaje->contenido); ?> </p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app34\resources\views/mensajes/show.blade.php ENDPATH**/ ?>