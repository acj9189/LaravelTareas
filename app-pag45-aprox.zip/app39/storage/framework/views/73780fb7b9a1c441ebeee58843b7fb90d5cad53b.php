<?php $__env->startSection('titulo'); ?>
    Tienda Online
<?php $__env->stopSection(); ?>



<?php $__env->startSection('contenido'); ?>
    <h1>Acerca de</h1>
    <br>
    <a href="/">Volver a la página inicial</a>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app30\resources\views/acercade.blade.php ENDPATH**/ ?>