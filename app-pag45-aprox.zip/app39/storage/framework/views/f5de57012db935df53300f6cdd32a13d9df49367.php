<?php $__env->startSection('titulo'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Página de inicio</h1>
    <form method="POST" action="login">
        <?php echo csrf_field(); ?>
        <input type="email" name="email" placeholder="Correo">
        <input type="password" name="password" placeholder="Contraseña">
        <input type="submit" value="Ingresar">
    </form>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app27\resources\views/auth/login.blade.php ENDPATH**/ ?>