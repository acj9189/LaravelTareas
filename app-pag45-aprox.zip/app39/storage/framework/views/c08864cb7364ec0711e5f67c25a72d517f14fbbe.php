<?php $__env->startSection('titulo', 'Contacto'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Contacto</h1>
	<!-- <form> (por defecto se envíarían por get) -->
	<form method="post" action=<?php echo e(route('contacto')); ?>>
			<?php echo csrf_field(); ?>
			<input name="nombre" placeholder="Nombre..."><br>
			<input type="email" name="correo" placeholder="Correo..."><br>
			<input name="asunto" placeholder="Asunto..."><br>
			<textarea name="contenido" placeholder="Mensaje..."></textarea><br>
			<button>Enviar</button>
	</form>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app14\resources\views/contacto.blade.php ENDPATH**/ ?>