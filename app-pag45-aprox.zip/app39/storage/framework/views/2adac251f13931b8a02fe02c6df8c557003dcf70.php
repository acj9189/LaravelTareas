<!DOCTYPE html>
<html lang="es">
    <head>
        <meta charset="UTF-8">
        <meta name="viewport" content="width=device-width, initial-scale=1.0">
        <meta http-equiv="X-UA-Compatible" content="ie=edge">
        <title>Mensajes de contactos</title>
    </head>
    <body>
        <p>Recibiste un mensaje de:  <?php echo e($mensaje['nombre']); ?> - <?php echo e($mensaje['correo']); ?></p>
		<p><strong>Asunto:</strong> <?php echo e($mensaje['asunto']); ?> </p>
		<p><strong>Contenido:</strong> <?php echo e($mensaje['contenido']); ?> </p>
    </body>
</html><?php /**PATH D:\laragon\www\app16\resources\views/emails/mensajes-recibidos.blade.php ENDPATH**/ ?>