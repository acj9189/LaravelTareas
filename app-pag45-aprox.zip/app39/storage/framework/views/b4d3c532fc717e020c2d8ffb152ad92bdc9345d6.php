<?php $__env->startSection('titulo', 'Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
	<br>
	<h3>Crear usuarios</h3>
	<br>
    
    <?php if(session()->has('info')): ?>
		<div class="alert alert-success"><?php echo e(session('info')); ?></div>
	<?php endif; ?>

    <form method="post" action=<?php echo e(route('usuarios.store')); ?>>
        
		<?php echo $__env->make('usuarios.form', ['usuario' => new App\User], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<button type="submit" class="btn btn-primary">Guardar</button>
	</form>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app36\resources\views/usuarios/crear.blade.php ENDPATH**/ ?>