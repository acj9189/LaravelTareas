<?php $__env->startSection('titulo', 'Todos los usuarios'); ?>

<?php $__env->startSection('contenido'); ?>
    <br>
	<h3>Todos los usuarios</h3>

    <table class="table">
        <thead>
                name
                email
                role
                address
                phone
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Tipo</th>
                <th>Dirección</th>
                <th>Teléfono</th>
                <th>Acciones</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $usuarios; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $usuario): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <td><?php echo e($usuario->name); ?></td>
                    <td><?php echo e($usuario->email); ?></td>
                    <td><?php echo e($usuario->role); ?></td>
                    <td><?php echo e($usuario->address); ?></td>
                    <td><?php echo e($usuario->phone); ?></td>
                    <td></td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app29\resources\views/usuarios/index.blade.php ENDPATH**/ ?>