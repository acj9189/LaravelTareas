<?php $__env->startSection('titulo', 'Contacto'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Contacto</h1>

	

	

	

	

	<form method="post" action=<?php echo e(route('mensajes.store')); ?>>
		<?php echo csrf_field(); ?>
		<input name="nombre" placeholder="Nombre..." value="<?php echo e(old('nombre')); ?>"><br>
		<?php echo $errors->first('nombre', '<small>:message</small>'); ?> <br>
		
		<input type="email" name="correo" placeholder="Correo..." value="<?php echo e(old('correo')); ?>"><br>
		<?php echo $errors->first('correo', '<small>:message</small>'); ?> <br>
		
		<input name="asunto" placeholder="Asunto..." value="<?php echo e(old('asunto')); ?>"><br>
		<?php echo $errors->first('asunto', '<small>:message</small>'); ?> <br>
		
		<textarea name="contenido" placeholder="Mensaje..." value="<?php echo e(old('contenido')); ?>"></textarea><br>
		<?php echo $errors->first('contenido', '<small>:message</small>'); ?> <br>

		<button>Enviar</button>
	</form>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app26\resources\views/mensajes/crear.blade.php ENDPATH**/ ?>