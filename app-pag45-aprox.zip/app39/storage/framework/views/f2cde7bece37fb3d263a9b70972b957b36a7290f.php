<?php $__env->startSection('titulo', 'Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
	<br>
	<h3>Editar usuarios</h3>
	<br>
    
    <?php if(session()->has('info')): ?>
		<div class="alert alert-success"><?php echo e(session('info')); ?></div>
	<?php endif; ?>

	<form method="post" action=<?php echo e(route('usuarios.update', $usuario->id)); ?>>
		<?php echo method_field('PUT'); ?>

		<?php echo $__env->make('usuarios.form', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
		<button type="submit" class="btn btn-primary">Actualizar</button>
	</form>	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app36\resources\views/usuarios/editar.blade.php ENDPATH**/ ?>