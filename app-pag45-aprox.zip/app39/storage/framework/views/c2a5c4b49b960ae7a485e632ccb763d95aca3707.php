<?php $__env->startSection('titulo'); ?>
    Catálogo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
   <h1>Catálogo de productos</h1>

   <ul>
        <?php if(isset($catalogo)): ?>
           <?php $__empty_1 = true; $__currentLoopData = $catalogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemCatalogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <li> <?php echo e($itemCatalogo->id); ?>-<?php echo e($itemCatalogo->nombre); ?> </li>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               <li>No hay productos para mostrar</li>
           <?php endif; ?>
        <?php else: ?>
           <li>Catálogo no definido</li>
        <?php endif; ?>

   </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app18\resources\views/catalogo.blade.php ENDPATH**/ ?>