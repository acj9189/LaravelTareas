<nav>
    <li class="<?php echo e(seleccionado('inicio')); ?>"><a href="/">Inicio</a></li>
    <li class="<?php echo e(seleccionado('acercade')); ?>"><a href="acercade">Acerca de...</a></li>
    <li class="<?php echo e(seleccionado('catalogo')); ?>"><a href="catalogo">Catálogo</a></li>

    <!-- enlace a la ruta del formulario, definida en web.php -->
    <li class="<?php echo e(seleccionado('mensajes.create')); ?>"><a href="<?php echo e(route('mensajes.create')); ?>">Contacto</a></li>
</nav><?php /**PATH D:\laragon\www\app18b\resources\views/partials/nav.blade.php ENDPATH**/ ?>