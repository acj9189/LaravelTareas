<nav>
    <!-- si las rutas no se resaltan debidamente, corregir x rutas con nombres -->
    <li class="<?php echo e(seleccionado('inicio')); ?>"><a href="<?php echo e(route('inicio')); ?>">Inicio</a></li>
    <li class="<?php echo e(seleccionado('acercade')); ?>"><a href="<?php echo e(route('acercade')); ?>">Acerca de...</a></li>
    <li class="<?php echo e(seleccionado('catalogo')); ?>"><a href="<?php echo e(route('catalogo')); ?>">Catálogo</a></li>
    <li class="<?php echo e(seleccionado('mensajes.create')); ?>"><a href="<?php echo e(route('mensajes.create')); ?>">Contacto</a></li>
    
    <!-- si existe un usuario autenticado actualmente -->
    <?php if(auth()->check()): ?>
        <li class="<?php echo e(seleccionado('mensajes.index')); ?>"><a href="<?php echo e(route('mensajes.index')); ?>">Mensajes</a></li>
        <li class="<?php echo e(seleccionado('/logout')); ?>"><a href="<?php echo e(route('logout')); ?>">Cerrar sesion de <?php echo e(auth()->user()->name); ?> </a></li>
    <?php endif; ?>
    
    <!-- sólo si es un usuario invitado, mostrar el formulario de autenticación -->
    <?php if(auth()->guest()): ?>
        <li class="<?php echo e(seleccionado('login')); ?>"><a href="<?php echo e(route('login')); ?>">Autenticarse</a></li>
    <?php endif; ?>
</nav><?php /**PATH D:\laragon\www\app27\resources\views/partials/nav.blade.php ENDPATH**/ ?>