<?php $__env->startSection('titulo', 'Xxxxxxx'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1><?php echo e($usuario->name); ?></h1>

    <table class="table">
		<tr>
			<th>Nombre:</th>
			<td><?php echo e($usuario->name); ?></td>
		</tr>
		<tr>
			<th>Email:</th>
			<td><?php echo e($usuario->email); ?></td>
		</tr>
		<tr>
			<th>Roles:</th>
			<td>
				<?php $__currentLoopData = $usuario->roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $role): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
					<?php echo e($role->descripcion); ?>

				<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
			</td>
		</tr>
    </table>
    
    <div class="btn-group" role="group">
        <div class="col-md-6 custom">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('edit', $usuario)): ?>
                <a href=<?php echo e(route('usuarios.edit', $usuario->id)); ?> class="btn btn-info">Editar</a>
            <?php endif; ?>
        </div>
        <div class="col-md-6 custom">
            <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('destroy', $usuario)): ?>
                <form method="POST" action="<?php echo e(route('usuarios.destroy', $usuario->id)); ?>">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('DELETE'); ?>

                    <button type="submit" class="btn btn-danger">Eliminar</button>
                </form>
            <?php endif; ?>
        </div>
    </div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app32\resources\views/usuarios/show.blade.php ENDPATH**/ ?>