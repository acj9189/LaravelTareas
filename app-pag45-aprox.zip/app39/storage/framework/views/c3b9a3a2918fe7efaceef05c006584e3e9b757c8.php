<?php $__env->startSection('titulo'); ?>
    Catálogo
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
   <h1>Catálogo de productos</h1>

   <ul>
        <!--
        <?php
            // 1a. forma de interar sobre el catálogo recibido desde ../routes/web.php
            foreach ($catalogo as $itemCatalogo) {
                echo "<li>" . $itemCatalogo['producto'] . "</li>";
            }
        ?>
        -->

        <!-- 2a. forma de interar sobre el catálogo recibido desde ../routes/web.php -->
        

        <!-- 3a. forma de interar, verificando si el array tiene elementos -->
        

        <!-- 4a. forma verificando si el catálogo existe y si el catálogo tiene datos -->
        

        <!-- 5a. forma usando forelse -->
        <?php if(isset($catalogo)): ?>
           <?php $__empty_1 = true; $__currentLoopData = $catalogo; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $itemCatalogo): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
               <li> <?php echo e($itemCatalogo['producto']); ?> </li>
               
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
               <li>No hay proyectos para mostrar</li>
           <?php endif; ?>
        <?php else: ?>
           <li>Catálogo no definido</li>
        <?php endif; ?>

   </ul>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app14\resources\views/catalogo.blade.php ENDPATH**/ ?>