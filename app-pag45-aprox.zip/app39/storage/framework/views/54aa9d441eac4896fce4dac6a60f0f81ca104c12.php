<?php $__env->startSection('titulo', 'Todos los mensajes'); ?>

<?php $__env->startSection('contenido'); ?>
    <br>
	<h3>Todos los mensajes</h3>

    <table class="table">
        <thead>
            <tr>
                <th>Nombre</th>
                <th>Correo</th>
                <th>Asunto</th>
                <th>Contenido</th>
                <th>Acciones</th>
            </tr>
        </thead>
        
        <tbody>
            <?php $__currentLoopData = $mensajes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $mensaje): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <tr>
                    <?php if($mensaje->user_id): ?>
                        <td>
                            <a href="<?php echo e(route('usuarios.show', $mensaje->user->id)); ?>"> 
                                <?php echo e($mensaje->user->name); ?>

                            </a>
                        </td> 
						<td><?php echo e($mensaje->user->email); ?></td>
					<?php else: ?>
						<td><?php echo e($mensaje->nombre); ?></td> 
						<td><?php echo e($mensaje->email); ?></td>
                    <?php endif; ?>
                    
                    <td>
						<a href="<?php echo e(route('mensajes.show', $mensaje->id)); ?>">
							<?php echo e($mensaje->asunto); ?>

						</a>
                    </td>
                    
                    <td><?php echo e($mensaje->contenido); ?></td>
                    
                    <td>
                        <div class="btn-group" role="group">
                            <div class="col-md-6 custom">
                                <a class="btn btn-info btn-sm" href="<?php echo e(route('mensajes.edit', $mensaje->id)); ?>">Editar</a>    
                            </div>
                            <div class="col-md-6 custom">
                                <form method="POST" action="<?php echo e(route('mensajes.destroy', $mensaje->id)); ?>">
                                    <?php echo csrf_field(); ?>
                                    <?php echo method_field('DELETE'); ?>

                                    <button type="submit" class="btn btn-sm btn-danger">Eliminar</button>
                                </form>
                            </div>
                        </div>
                    </td>
                </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app34\resources\views/mensajes/index.blade.php ENDPATH**/ ?>