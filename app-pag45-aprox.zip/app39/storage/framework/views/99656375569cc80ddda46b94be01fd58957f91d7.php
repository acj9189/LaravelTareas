<?php $__env->startSection('titulo'); ?>
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <br>
    <h2>Autenticación de usuarios</h2>

    <form class="form-inline" method="POST" action="login">
        <?php echo csrf_field(); ?>

        <div class="form-group">
            <input type="email" class="form-control" id="email" name="email" placeholder="Ingrese su correo">
        </div>

        <div class="form-group mx-sm-3">
            <input type="password" class="form-control" id="password" name="password" placeholder="Ingrese su contraseña">
        </div>

        <input class="btn btn-primary" type="submit" value="Ingresar">
    </form>
    <br>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app33\resources\views/auth/login.blade.php ENDPATH**/ ?>