<?php echo csrf_field(); ?>

<div class="form-group">
    <label for="name">Nombre</label>
    <input type="input" class="form-control" id="name" name="name" placeholder="Ingrese su nombre" value="<?php echo e($usuario->name ?? old('name')); ?>">
    <?php echo $errors->first('name', '<<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="email">Correo</label>
    <input type="email" class="form-control" id="email" name="email" placeholder="Ingrese su correo electrónico" value="<?php echo e($usuario->email ?? old('email')); ?>">
    <?php echo $errors->first('email', '<<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="address">Dirección</label>
    <input type="input" class="form-control" id="address" name="address" placeholder="Dirección de residencia" value="<?php echo e($usuario->address ?? old('address')); ?>">
    <?php echo $errors->first('address', '<span class=error>:message</span>'); ?>

</div>

<div class="form-group">
    <label for="phone">Teléfono</label>
    <input type="input" class="form-control" id="phone" name="phone" placeholder="Teléfono móvil preferiblemente" value="<?php echo e($usuario->phone ?? old('phone')); ?>">
    <?php echo $errors->first('phone', '<span class=error>:message</span>'); ?>

</div>

<?php if (! ($usuario->id)): ?> 
    <div class="form-group">
            <label for="password">Contraseña</label>
            <input type="password" class="form-control" id="password" name="password" placeholder="Contraseña..." value="<?php echo e($usuario->password); ?>">
            <?php echo $errors->first('password', '<span class=error>:message</span>'); ?>

    </div>

    <div class="form-group">
            <label for="password_confirmation">Confirme la contraseña</label>
            <input type="password" class="form-control" id="password_confirmation" name="password_confirmation" placeholder="Reingrese la contraseña" value="<?php echo e($usuario->password); ?>">
            <?php echo $errors->first('password_confirmation', '<span class=error>:message</span>'); ?>

    </div>
<?php endif; ?>

<div class="checkbox">
    Privilegios:
    <?php $__currentLoopData = $roles; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $id => $nombre): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <label>
            &nbsp;&nbsp;
            <input type="checkbox" name="roles[]" value="<?php echo e($id); ?>" 
                <?php echo e($usuario->roles->pluck('id')->contains($id) ? 'checked' : ''); ?>

            >
            <?php echo e($nombre); ?>

        </label>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
</div>
<?php echo $errors->first('roles', '<span class=error>:message</span>'); ?>

<hr><?php /**PATH D:\laragon\www\app37\resources\views/usuarios/form.blade.php ENDPATH**/ ?>