<?php $__env->startSection('titulo', 'Mensaje'); ?>

<?php $__env->startSection('contenido'); ?>
	<h1>Mensaje</h1>

	
	<form method="post" action=<?php echo e(route('mensajes.update', $mensaje->id)); ?>>
		<?php echo method_field('PUT'); ?>

		<?php echo $__env->make('mensajes.form', ['btnText' => 'Actualizar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
	</form>	

<?php $__env->stopSection(); ?>
<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app35\resources\views/mensajes/editar.blade.php ENDPATH**/ ?>