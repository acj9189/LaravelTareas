<nav class="navbar navbar-expand-sm navbar-dark bg-primary">
    <a class="navbar-brand" href="#">Menú</a>

    <button class="navbar-toggler d-lg-none" type="button" data-toggle="collapse" data-target="#collapsibleNavId" aria-controls="collapsibleNavId"
        aria-expanded="false" aria-label="Toggle navigation">
    </button>

    <div class="collapse navbar-collapse" id="collapsibleNavId">
        <ul class="navbar-nav mr-auto mt-2 mt-lg-0">

            <li class="<?php echo e(seleccionado('inicio')); ?>">
                <a class="nav-link" href="<?php echo e(route('inicio')); ?>">Inicio <span class="sr-only">(current)</span></a>
            </li>

            <li class="<?php echo e(seleccionado('catalogo')); ?>">
                <a class="nav-link" href="<?php echo e(route('catalogo')); ?>">Productos</a>
            </li>

            <li class="<?php echo e(seleccionado('mensajes.create')); ?>">
                <a class="nav-link" href="<?php echo e(route('mensajes.create')); ?>">Contacto</a>
            </li>
            <!-- ************ modificado *********************** -->
            <?php if(auth()->check()): ?>
                <li class="<?php echo e(seleccionado('mensajes.index')); ?>">
                    <a class="nav-link" href="<?php echo e(route('mensajes.index')); ?>">Mensajes</a>
                </li>
                <?php if(auth()->user()->hasRoles(['administrador', 'editor'])): ?>
                    <li class="<?php echo e(seleccionado('usuarios*')); ?>">
                        <a class="nav-link" href="<?php echo e(route('usuarios.index')); ?>">Usuarios</a>
                    </li>
                <?php endif; ?>
            <?php endif; ?>

            <li class="<?php echo e(seleccionado('acercade')); ?>">
                <a class="nav-link" href="<?php echo e(route('acercade')); ?>">Acerca de...</a>
            </li>

        </ul>

        <ul class="navbar-nav ">
            <?php if(auth()->guest()): ?>
                <!-- si existe un usuario invitado -->
                <li class="<?php echo e(seleccionado('login')); ?>">
                    <a class="nav-link" href="<?php echo e(route('login')); ?>">Autenticarse</a>
                </li>
			<?php else: ?>
                <li class="dropdown">
                    <a class="nav-link dropdown-toggle" href="<?php echo e(route('mensajes.index')); ?>" data-toggle="dropdown">
                        <?php echo e(auth()->user()->name); ?>

                    </a>

                    <ul class="dropdown-menu dropdown-menu-right">
                        <li class="nav-item">
                            <li><a class="dropdown-item" href="/usuarios/<?php echo e(auth()->id()); ?>/edit">Mi cuenta</a><li>
                            <li><a class="dropdown-item" href="<?php echo e(route('logout')); ?>">Cerrar sesión</a><li>
                        </li>
                    </ul>
                </li>
            <?php endif; ?>
        </ul>
    </div>
</nav>
<?php /**PATH D:\laragon\www\app38\resources\views/partials/nav.blade.php ENDPATH**/ ?>