<?php $__env->startSection('titulo', 'Usuario'); ?>

<?php $__env->startSection('contenido'); ?>
    <h1>Editar usuarios</h1>
    
    <?php if(session()->has('info')): ?>
		<div class="alert alert-success"><?php echo e(session('info')); ?></div>
	<?php endif; ?>

	<form method="post" action=<?php echo e(route('usuarios.update', $usuario->id)); ?>>
		<?php echo csrf_field(); ?>
        <?php echo method_field('PUT'); ?>


		<input name="name" placeholder="Nombre..." value="<?php echo e($usuario->name); ?>"><br>
		<?php echo $errors->first('name', '<small>:message</small>'); ?> <br>
		
		<input type="email" name="email" placeholder="Correo..." value="<?php echo e($usuario->email); ?>"><br>
		<?php echo $errors->first('email', '<small>:message</small>'); ?> <br>

        <input name="address" placeholder="Dirección..." value="<?php echo e($usuario->address); ?>"><br>
		<?php echo $errors->first('address', '<small>:message</small>'); ?> <br>

        <input name="phone" placeholder="Teléfono..." value="<?php echo e($usuario->phone); ?>"><br>
		<?php echo $errors->first('phone', '<small>:message</small>'); ?> <br>

		<button>Enviar</button>
	</form>	

<?php $__env->stopSection(); ?>


<?php echo $__env->make('plantilla', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\laragon\www\app31\resources\views/usuarios/editar.blade.php ENDPATH**/ ?>