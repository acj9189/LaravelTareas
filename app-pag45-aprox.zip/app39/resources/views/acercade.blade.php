@extends('plantilla')

@section('titulo')
    Tienda Online
@endsection

{{-- cuando el contenido es corto se puede usar:  @section('sección', 'contenido') --}}

@section('contenido')
    <h1>Acerca de</h1>
    <br>
    <a href="/">Volver a la página inicial</a>
@endsection